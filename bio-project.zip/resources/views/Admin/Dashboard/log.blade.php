<!DOCTYPE html>
<html>
<head>
  <title>Test</title>
</head>
<body>
  <button onclick="functionUnshift()">Tes</button>
  <p id="test"></p>
  <script>
    var angka = [1,2,3,4,5];


    console.log(angka);
    console.log(angka.unshift(10));
    console.log(angka);
    console.log(angka.pop());
    console.log(angka);
  </script>
</body>
</html>
<p>Alert</p>
<p>Cek sekarang juga!</p>
<p>{{ $user }}</p>